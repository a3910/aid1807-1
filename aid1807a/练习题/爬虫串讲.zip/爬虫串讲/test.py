from lxml import etree

with open('示例文件.xml','r') as f:
    html = etree.HTML(f.read().encode())
result = html.xpath('//book')
image = result[0].xpath('.//title/text()')
iclass = result[0].xpath('.//title/@class')
print(type(image),image,iclass)
print(result)