# -*- coding:utf-8 -*-
import re
from time import sleep
from lxml import etree
import requests

def myreq(url):
    '''输入网址，输出HTML对象'''
    headers = {
    'User-Agent':'Mozilla/5.0 (X11; Linux x86_64; rv:57.0) Gecko/20100101 Firefox/57.0',
    "Host":'maoyan.com',
    'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
    }

    request = requests.get(url = url,headers=headers)
    req = request.text.encode(request.encoding).decode('utf8')
    html = etree.HTML(req)
    # result = etree.tostring(html, pretty_print=True, encoding='utf8')
    return html

if __name__ == '__main__':
    for i in range(10):
        nums = i*10
        url = 'http://maoyan.com/board/4?offset='+str(nums)
        result = myreq(url)
        result = result.xpath('//dd')
        sleep(3)
        for page in result:
            image = page.xpath('.//img[@data-src]/@data-src')[0]
            name = page.xpath('.//p[@class="name"]/a/text()')[0]
            star = page.xpath('.//p[@class="star"]/text()')[0]
            releasetime = page.xpath('.//p[@class="releasetime"]/text()')[0]
            star = re.sub('[(\n)( )+|( )+(\n)]','',star)
            releasetime = re.sub('[(\n)( )+|( )+(\n)]','',releasetime)
            print(releasetime,star)
            with open('maoyantop100.txt','a') as f:
                f.writelines('image:{},\nname:{},\nstar:{},\nreleasetime:{}\n\n\n'.format(image,name,star,releasetime))
            sleep(0.3)