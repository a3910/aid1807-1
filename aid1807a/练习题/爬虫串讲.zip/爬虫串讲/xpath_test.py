from lxml import etree

with open('maoyan.html','r') as f:
    html = etree.HTML(f.read().encode('utf-8'))
result = html.xpath('//dd')
